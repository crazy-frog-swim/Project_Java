package car_rental;

/**
 *
 * @author Lim En Yi (TP060710) Keshinie A/P Sajeevan (TP066216)
 */
public class Car_Rental {

    public static void main(String[] args) {
        new MainPage().setVisible(true);
    }
}
